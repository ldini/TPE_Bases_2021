create function after_update_voluntario_sethours() returns trigger
    language plpgsql
as
$$
BEGIN
            update voluntario set horas_aportadas = 0
            where new.nro_voluntario=voluntario.nro_voluntario;
            
            return new;
        END;
$$;

alter function after_update_voluntario_sethours() owner to unc_248909;

