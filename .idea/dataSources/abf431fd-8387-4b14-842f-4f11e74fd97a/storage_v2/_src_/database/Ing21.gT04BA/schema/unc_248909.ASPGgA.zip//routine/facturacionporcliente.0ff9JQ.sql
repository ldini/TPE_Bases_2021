create function facturacionporcliente(id_cliente integer) returns comprobante
    language plpgsql
as
$$
BEGIN

        end;
$$;

alter function facturacionporcliente(integer) owner to unc_248909;

