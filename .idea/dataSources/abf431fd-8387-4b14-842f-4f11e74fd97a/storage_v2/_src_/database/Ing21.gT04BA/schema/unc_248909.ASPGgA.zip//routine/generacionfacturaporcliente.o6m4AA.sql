create function generacionfacturaporcliente(cliente integer) returns comprobante
    language plpgsql
as
$$
DECLARE
            counter bigint=1000;
            factura comprobante;
        BEGIN
                INSERT INTO comprobante values (counter,1,now(),'Facturacion Mensual',NULL,NULL,NULL,0,cliente);
                counter=counter+1;
                call generacionLineasComprobantePorCliente(cliente,factura);
                return factura;
        end
$$;

alter function generacionfacturaporcliente(integer) owner to unc_248909;

