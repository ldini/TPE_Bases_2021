create procedure generacionlineascomprobanteporcliente(id_cliente integer, factura comprobante)
    language plpgsql
as
$$
DECLARE
            datos record;
            counter int=0;
            cliente int = id_cliente;
        BEGIN
                for datos in (SELECT * FROM servicios_ClientesActivos)
                    loop
                        counter=counter+1;
                        UPDATE factura set importe=importe+datos.costo where factura.id_cliente=datos.id_cliente;
                        INSERT INTO lineacomprobante values (counter,factura.id_comp,factura.id_tcomp,datos.nombre,1,datos.costo,datos.id_servicio);
                end loop;
        end;
$$;

alter procedure generacionlineascomprobanteporcliente(integer, comprobante) owner to unc_248909;

