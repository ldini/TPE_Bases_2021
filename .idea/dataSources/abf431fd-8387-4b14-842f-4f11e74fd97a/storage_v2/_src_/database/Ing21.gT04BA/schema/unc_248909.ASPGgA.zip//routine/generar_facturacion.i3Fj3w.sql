create procedure generar_facturacion()
    language plpgsql
as
$$
DECLARE
        var_cliente int;
    BEGIN
        FOR var_cliente IN (SELECT DISTINCT e.id_cliente
                            FROM equipo e) --Por todos los clientes activos(que tienen equipo), genero la factura.
        LOOP
            call generar_facturaPorCliente(var_cliente);
        END LOOP;
    END;
$$;

alter procedure generar_facturacion() owner to unc_248909;

