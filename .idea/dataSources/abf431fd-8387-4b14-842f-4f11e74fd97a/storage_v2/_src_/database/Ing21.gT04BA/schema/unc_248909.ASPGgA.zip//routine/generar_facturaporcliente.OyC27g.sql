create procedure generar_facturaporcliente(param_idcliente integer)
    language plpgsql
as
$$
DECLARE
        var_comp comprobante;
        rec_service record;
        var_nroLinea int = 0;
    BEGIN
        var_comp.id_comp = (SELECT max(c.id_comp)
                            FROM comprobante c
                            LIMIT 1) +1;
        var_comp.id_tcomp = 1; --1 equivale a tipo factura
        var_comp.fecha = current_timestamp;
        var_comp.comentario = 'Facturacion mensual';
        var_comp.estado = null;
        var_comp.fecha_vencimiento = null; -- Podria ponerle la fecha de vencimiento con (current_timestamp + interval '1 month')::timestamp;
        var_comp.id_turno = null;
        var_comp.importe = 0;
        var_comp.id_cliente = param_idCliente;
        INSERT INTO comprobante(id_comp, id_tcomp, fecha, comentario, estado, fecha_vencimiento, id_turno, importe, id_cliente)
                VALUES (var_comp.id_comp,var_comp.id_tcomp, var_comp.fecha, var_comp.comentario, var_comp.estado,
                        var_comp.fecha_vencimiento, var_comp.id_turno,var_comp.importe,var_comp.id_cliente);

        FOR rec_service IN (SELECT s.id_servicio, s.costo, s.nombre FROM servicio s
                            WHERE s.id_servicio IN (SELECT e.id_servicio FROM equipo e
                                                    WHERE e.id_cliente = var_comp.id_cliente))
        LOOP
            call generar_lineasFactura(var_comp,rec_service, var_nroLinea);
            var_nroLinea = var_nroLinea+1;
        END LOOP;
    END;
$$;

alter procedure generar_facturaporcliente(integer) owner to unc_248909;

