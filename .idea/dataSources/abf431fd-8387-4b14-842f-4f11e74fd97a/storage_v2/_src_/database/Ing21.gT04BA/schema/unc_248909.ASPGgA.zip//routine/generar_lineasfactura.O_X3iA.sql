create procedure generar_lineasfactura(param_comprobante comprobante, param_recservicio record, param_nrolinea integer)
    language plpgsql
as
$$
DECLARE
        linea lineacomprobante;
    BEGIN
        linea.nro_linea = param_comprobante;
        linea.id_comp = param_comprobante.id_comp;
        linea.id_tcomp = param_comprobante.id_tcomp;
        linea.descripcion = param_recServicio.nombre;
        linea.cantidad = 1;
        linea.importe = param_recServicio.costo;
        linea.id_servicio= param_recServicio.id_servicio;
        param_comprobante.importe = param_comprobante.importe + linea.importe;

        UPDATE comprobante SET importe = param_comprobante.importe
                WHERE comprobante.id_tcomp = param_comprobante.id_tcomp
                                            AND comprobante.id_comp = param_comprobante.id_comp;

        INSERT INTO lineacomprobante(nro_linea, id_comp, id_tcomp, descripcion, cantidad, importe, id_servicio)
                VALUES(linea.nro_linea, linea.id_comp, linea.id_tcomp,linea.descripcion,linea.cantidad,
                       linea.importe,linea.id_servicio);
    END;
$$;

alter procedure generar_lineasfactura(comprobante, record, integer) owner to unc_248909;

