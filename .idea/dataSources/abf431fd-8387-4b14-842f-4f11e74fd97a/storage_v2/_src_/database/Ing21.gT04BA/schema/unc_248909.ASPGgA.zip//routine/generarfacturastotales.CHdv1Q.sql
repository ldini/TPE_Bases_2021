create procedure generarfacturastotales()
    language plpgsql
as
$$
declare
            datosCliente record;
            tipoFactura int=1;
        BEGIN
            for datosCliente in (select id_cliente from cliente) loop
                select generacionFacturaPorCliente(datosCliente.id_cliente);
            end loop;
        END;
$$;

alter procedure generarfacturastotales() owner to unc_248909;

