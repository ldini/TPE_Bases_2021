create function informe_empleados_btwdates(fecha_inicio timestamp without time zone, fecha_fin timestamp without time zone)
    returns TABLE(id_personal integer, id_ciudad integer, cantidad bigint, promediohs double precision, max double precision)
    language plpgsql
as
$$
BEGIN
            return query
                SELECT p.id_personal, b.id_ciudad,count(turno.id_turno)cantidadTurnosResueltos,
                        AVG(EXTRACT(epoch from(turno.hasta - turno.desde))/3600),MAX(EXTRACT(epoch from(turno.hasta-turno.desde)))
                FROM (  select personal.id_personal
                        from personal
                        where personal.id_personal='4') p --se entiende que el id_rol='1' es el rol de empleado
                    JOIN(   SELECT t.id_personal,t.id_turno,t.hasta,t.desde
                            FROM turno t
                            WHERE (t.hasta is not null AND (fecha_inicio <= t.desde
                                                        AND fecha_fin <= t.hasta))
                        ) turno on p.id_personal = turno.id_personal
                    JOIN (  SELECT c.id_turno, c.id_cliente
                            FROM comprobante c
                         ) comprobante on turno.id_turno=comprobante.id_turno
                    JOIN direccion d on comprobante.id_cliente=d.id_persona
                    JOIN barrio b on d.id_barrio = b.id_barrio
                    GROUP BY p.id_personal,b.id_ciudad;
        END;
$$;

alter function informe_empleados_btwdates(timestamp, timestamp) owner to unc_248909;

