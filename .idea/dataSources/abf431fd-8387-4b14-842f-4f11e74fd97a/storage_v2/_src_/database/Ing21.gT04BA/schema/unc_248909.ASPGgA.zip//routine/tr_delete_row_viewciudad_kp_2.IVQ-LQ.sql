create function tr_delete_row_viewciudad_kp_2() returns trigger
    language plpgsql
as
$$
BEGIN
            DELETE FROM ciudad
                WHERE old.id_ciudad = ciudad.id_ciudad;
            return old;
        end;
$$;

alter function tr_delete_row_viewciudad_kp_2() owner to unc_248909;

