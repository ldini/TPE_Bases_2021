create function tr_insert_btwnhsaportadas() returns trigger
    language plpgsql
as
$$
BEGIN
            IF (EXISTS(SELECT 1
                       FROM voluntario v
                                JOIN tarea t on v.id_tarea = t.id_tarea
                       WHERE ((v.horas_aportadas NOT BETWEEN t.min_horas AND t.max_horas)
                           AND (new.nro_voluntario = v.nro_voluntario))
                )
            )THEN
                RAISE EXCEPTION 'El voluntario esta por fuera del rango de hs aportadas';
            end if;
        end;
$$;

alter function tr_insert_btwnhsaportadas() owner to unc_248909;

