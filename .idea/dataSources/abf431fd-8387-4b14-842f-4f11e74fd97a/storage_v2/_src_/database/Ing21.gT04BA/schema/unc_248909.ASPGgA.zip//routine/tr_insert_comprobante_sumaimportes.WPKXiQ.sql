create function tr_insert_comprobante_sumaimportes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (EXISTS (SELECT 1
                FROM comprobante c
                WHERE c.importe <> (SELECT SUM(l.importe)
                                    FROM lineacomprobante l
                                    WHERE c.id_comp=l.id_comp
                                            AND c.id_tcomp=l.id_tcomp)
       )) THEN
        RAISE EXCEPTION 'El importe de un comprobante debe coincidir con la suma de los importes de sus líneas';
    END IF;
    return new;
END;
$$;

alter function tr_insert_comprobante_sumaimportes() owner to unc_248909;

