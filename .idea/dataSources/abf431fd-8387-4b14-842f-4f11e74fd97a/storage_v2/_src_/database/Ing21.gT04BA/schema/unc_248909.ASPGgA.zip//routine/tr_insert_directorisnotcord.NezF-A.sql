create function tr_insert_directorisnotcord() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (EXISTS( SELECT 1
                    FROM voluntario v
                        WHERE new.id_director=v.id_coordinador
            ))
            THEN
                RAISE EXCEPTION 'El director tiene que ser coordinador con gente a cargo';
        end if;
    end;
$$;

alter function tr_insert_directorisnotcord() owner to unc_248909;

