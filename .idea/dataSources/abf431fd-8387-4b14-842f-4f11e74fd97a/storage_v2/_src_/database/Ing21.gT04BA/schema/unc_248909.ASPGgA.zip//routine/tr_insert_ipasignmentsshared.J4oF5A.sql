create function tr_insert_ipasignmentsshared() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (EXISTS (SELECT 1
                FROM cliente c
                    JOIN equipo e on c.id_cliente=e.id_cliente
                WHERE e.ip in ( SELECT e2.ip
                                FROM cliente c2
                                    JOIN equipo e2 on c2.id_cliente = e2.id_cliente
                                WHERE c.id_cliente <> c2.id_cliente AND e.ip=e2.ip
                              )
                )) THEN
        RAISE EXCEPTION 'La IP ingresada ya la tiene otro cliente.';
    END IF;
    return new;
END;
$$;

alter function tr_insert_ipasignmentsshared() owner to unc_248909;

