create function tr_insert_row_viewciudad_kp_2() returns trigger
    language plpgsql
as
$$
BEGIN
            raise notice 'id pais %', new.id_pais;
            raise notice 'id_ciudad%',new.id_ciudad;
            IF(NOT EXISTS(  SELECT 1
                            FROM pais
                            WHERE id_pais=new.id_pais))
                THEN
                    raise notice 'No existe pais';
                    insert into pais(id_pais,nombre_pais)values (new.id_pais,new.nombre_pais);
            end if;
            IF(NOT EXISTS(  SELECT 1
                            FROM ciudad
                            WHERE id_ciudad=new.id_ciudad))
                THEN
                    raise notice 'No existe ciudad';
                    insert into ciudad(id_ciudad, nombre_ciudad, id_pais) values
                                (new.id_ciudad,new.nombre_ciudad,new.id_pais);
            end if;
            return new;
        end;
$$;

alter function tr_insert_row_viewciudad_kp_2() owner to unc_248909;

