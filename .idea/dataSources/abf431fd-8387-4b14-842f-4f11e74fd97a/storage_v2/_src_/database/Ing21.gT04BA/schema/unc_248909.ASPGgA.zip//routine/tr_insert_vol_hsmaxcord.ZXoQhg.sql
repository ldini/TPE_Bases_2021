create function tr_insert_vol_hsmaxcord() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (EXISTS (SELECT 1
                FROM voluntario v
                    JOIN voluntario jefe on v.id_coordinador = jefe.nro_voluntario
                WHERE ((v.horas_aportadas>jefe.horas_aportadas)
                           AND(new.nro_voluntario = v.nro_voluntario)
                    )
       )) THEN
            RAISE EXCEPTION 'El voluntario aporta mas horas que su coordinador';
    END IF;
    return new;
END;
$$;

alter function tr_insert_vol_hsmaxcord() owner to unc_248909;

