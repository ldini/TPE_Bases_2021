create function tr_instead_insert_servicio_servicioscliente() returns trigger
    language plpgsql
as
$$
BEGIN
            IF (tg_op = 'INSERT') THEN
                RAISE EXCEPTION 'No se puede insertar en la vista';
            ELSE
                IF(new.id_servicio in (select id_servicio
                                        FROM servicio))
                    THEN
                        UPDATE servicio SET costo = new.costo where id_servicio = new.id_servicio;
                ELSE
                    RAISE EXCEPTION 'El servicio ingresado no existe.';
                END IF;
             END IF;
            return new;
        end;
$$;

alter function tr_instead_insert_servicio_servicioscliente() owner to unc_248909;

