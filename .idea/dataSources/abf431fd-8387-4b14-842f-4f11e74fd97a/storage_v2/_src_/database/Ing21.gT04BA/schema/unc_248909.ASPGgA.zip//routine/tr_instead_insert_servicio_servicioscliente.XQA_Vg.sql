create function tr_instead_insert_servicio_servicioscliente() returns trigger
    language plpgsql
as
$$
BEGIN
            IF (EXISTS( SELECT 1
                        FROM Servicio s
                        WHERE (s.id_servicio=new.id_servicio) OR (new.activo=false)))
                THEN
                    RAISE EXCEPTION 'El servicio a insertar ya existe o no esta activo';
            end if;
            IF(new.id_cat NOT IN(   SELECT id_cat
                                    FROM categoria))
                THEN
                    RAISE EXCEPTION 'La categoria ingresada no existe';
            end if;
            INSERT INTO servicio (id_servicio, nombre, periodico, costo, activo, id_cat)
                                values (new.id_servicio,new.nombre,new.periodico,new.costo,true,new.id_cat);
            return new;
        end;
$$;

alter function tr_instead_insert_servicio_servicioscliente() owner to unc_248909;

