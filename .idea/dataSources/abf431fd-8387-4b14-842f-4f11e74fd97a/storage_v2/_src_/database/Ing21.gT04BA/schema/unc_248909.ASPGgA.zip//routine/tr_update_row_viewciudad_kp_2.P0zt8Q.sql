create function tr_update_row_viewciudad_kp_2() returns trigger
    language plpgsql
as
$$
BEGIN
            update ciudad set id_ciudad=new.id_ciudad,
                              nombre_ciudad=new.nombre_ciudad
            where id_ciudad=new.id_ciudad;
            update pais set id_pais=new.id_pais,
                            nombre_pais=new.nombre_pais
            where id_pais=new.id_pais;
            return new;
        end;
$$;

alter function tr_update_row_viewciudad_kp_2() owner to unc_248909;

