create function tr_voltareaequalcordtarea() returns trigger
    language plpgsql
as
$$
BEGIN
            IF(EXISTS(SELECT 1
                      FROM voluntario v
                        JOIN voluntario cord on v.id_coordinador=cord.nro_voluntario
                      WHERE((v.id_tarea!=cord.id_tarea)
                            AND new.nro_voluntario = v.nro_voluntario)))
                THEN
                    RAISE EXCEPTION 'El voluntario no realiza la misma tarea que su coordinador';
            end if;
        end;
$$;

alter function tr_voltareaequalcordtarea() owner to unc_248909;

