create view inventario_consolidado_equipo(nombre, tipo_conexion, tipo_asignacion, cantequipos) as
SELECT e.nombre,
       e.tipo_conexion,
       e.tipo_asignacion,
       count(*) AS cantequipos
FROM equipo e
WHERE e.fecha_baja IS NULL
GROUP BY e.tipo_conexion, e.tipo_asignacion, e.nombre;

alter table inventario_consolidado_equipo
    owner to unc_248909;

