create view nombreconsulta(id_cliente, sum) as
SELECT comprobante.id_cliente,
       sum(comprobante.importe) AS sum
FROM comprobante
WHERE date_part('month'::text, comprobante.fecha) = (date_part('month'::text, CURRENT_DATE) - 1::double precision)
  AND ((comprobante.id_comp, 3) IN (SELECT lineacomprobante.id_comp,
                                           lineacomprobante.id_tcomp
                                    FROM lineacomprobante
                                    WHERE (lineacomprobante.id_servicio IN (SELECT servicio.id_servicio
                                                                            FROM servicio
                                                                            WHERE servicio.periodico = true))))
GROUP BY comprobante.id_cliente;

alter table nombreconsulta
    owner to unc_248909;

