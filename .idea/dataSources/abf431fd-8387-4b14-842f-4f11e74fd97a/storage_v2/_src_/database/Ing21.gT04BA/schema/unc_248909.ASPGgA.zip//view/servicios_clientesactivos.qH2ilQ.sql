create view servicios_clientesactivos(id_cliente, id_servicio, costo, nombre) as
SELECT e.id_cliente,
       s.id_servicio,
       s.costo,
       s.nombre
FROM equipo e
         JOIN (SELECT servicio.id_servicio,
                      servicio.costo,
                      servicio.nombre
               FROM servicio
               WHERE servicio.periodico = true
                 AND servicio.activo = true) s ON e.id_servicio = s.id_servicio;

alter table servicios_clientesactivos
    owner to unc_248909;

