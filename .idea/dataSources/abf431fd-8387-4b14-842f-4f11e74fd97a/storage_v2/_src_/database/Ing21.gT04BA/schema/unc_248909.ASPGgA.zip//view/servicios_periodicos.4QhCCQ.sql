create view servicios_periodicos(id_servicio) as
SELECT servicio.id_servicio
FROM servicio
WHERE servicio.periodico = true
with local check option;

alter table servicios_periodicos
    owner to unc_248909;

