create view testvista(id_cliente, id_comp, id_tcomp) as
SELECT comprobante.id_cliente,
       comprobante.id_comp,
       comprobante.id_tcomp
FROM comprobante
WHERE comprobante.id_tcomp = 3
  AND ((comprobante.id_comp, comprobante.id_tcomp) IN (SELECT lineacomprobante.id_comp,
                                                              lineacomprobante.id_tcomp
                                                       FROM lineacomprobante
                                                       WHERE (lineacomprobante.id_servicio IN
                                                              (SELECT servicio.id_servicio
                                                               FROM servicio
                                                               WHERE servicio.periodico = true))));

alter table testvista
    owner to unc_248909;

