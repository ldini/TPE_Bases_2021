create view testvistaa(id_comp, id_tcomp, id_cliente, importe) as
SELECT c.id_comp,
       c.id_tcomp,
       c.id_cliente,
       c.importe
FROM comprobante c
         JOIN (SELECT lineacomprobante.nro_linea,
                      lineacomprobante.id_comp,
                      lineacomprobante.id_tcomp,
                      lineacomprobante.descripcion,
                      lineacomprobante.cantidad,
                      lineacomprobante.importe,
                      lineacomprobante.id_servicio
               FROM lineacomprobante
               WHERE lineacomprobante.id_tcomp = 3) l ON c.id_comp = l.id_comp AND c.id_tcomp = l.id_tcomp
         JOIN (SELECT servicio.id_servicio,
                      servicio.nombre,
                      servicio.periodico,
                      servicio.costo,
                      servicio.intervalo,
                      servicio.tipo_intervalo,
                      servicio.activo,
                      servicio.id_cat
               FROM servicio
               WHERE servicio.periodico = true) s ON l.id_servicio = s.id_servicio;

alter table testvistaa
    owner to unc_248909;

