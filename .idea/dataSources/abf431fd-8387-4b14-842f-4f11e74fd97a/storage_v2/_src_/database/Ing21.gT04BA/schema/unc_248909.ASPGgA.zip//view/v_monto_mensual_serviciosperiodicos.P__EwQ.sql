create view v_monto_mensual_serviciosperiodicos(id_servicio, mes, año, sum) as
SELECT s.id_servicio,
       date_part('month'::text, c.fecha) AS mes,
       date_part('year'::text, c.fecha)  AS "año",
       sum(l.importe)                    AS sum
FROM comprobante c
         JOIN lineacomprobante l ON c.id_comp = l.id_comp AND c.id_tcomp = l.id_tcomp
         JOIN servicio s ON l.id_servicio = s.id_servicio
WHERE date_part('year'::text, c.fecha) > (date_part('year'::text, CURRENT_DATE) - 5::double precision)
  AND s.periodico = true
GROUP BY s.id_servicio, (date_part('year'::text, c.fecha)), (date_part('month'::text, c.fecha))
ORDER BY (date_part('year'::text, c.fecha));

alter table v_monto_mensual_serviciosperiodicos
    owner to unc_248909;

