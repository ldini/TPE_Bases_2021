create view v_saldo_ciudad(id_cliente, saldo) as
SELECT c.id_cliente,
       c.saldo
FROM cliente c
WHERE (c.id_cliente IN (SELECT d.id_persona
                        FROM ciudad c_1
                                 JOIN barrio b ON c_1.id_ciudad = b.id_ciudad
                                 JOIN direccion d ON b.id_barrio = d.id_barrio
                        WHERE c_1.nombre::text ~~ 'Tandil'::text))
with local check option;

alter table v_saldo_ciudad
    owner to unc_248909;

