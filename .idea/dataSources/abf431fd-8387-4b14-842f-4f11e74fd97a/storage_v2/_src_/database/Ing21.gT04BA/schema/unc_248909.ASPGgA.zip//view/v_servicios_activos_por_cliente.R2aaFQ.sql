create view v_servicios_activos_por_cliente(id_cliente, id_servicio, costo) as
SELECT DISTINCT e.id_cliente,
                s.id_servicio,
                s.costo
FROM servicio s
         JOIN equipo e ON s.id_servicio = e.id_servicio
WHERE s.activo = true
ORDER BY e.id_cliente;

alter table v_servicios_activos_por_cliente
    owner to unc_248909;

